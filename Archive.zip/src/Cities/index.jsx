import React from "react";

const Index = () => {
    return(
        <>
        <h1>This is Good </h1>
        </>
    )

}

export default Index;