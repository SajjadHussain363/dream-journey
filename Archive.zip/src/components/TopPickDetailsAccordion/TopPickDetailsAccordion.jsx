import React from "react";

// Custom hook for image preloading
const TopPickDetailsAccordion = (GET) => {
    

    return (
        <div>
            <h1>TopPickDetailsAccordion</h1>
            
        </div>
    );
};

export default TopPickDetailsAccordion;
