import React, { useState } from 'react';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import { Container, Row, Col } from 'react-bootstrap';
import "./PayNowOrLater.css";
import PayNowOrLaterCompo from '../../components/PayNowOrLaterCompo/PayNowOrLaterCompo';
import GetOffersDeals from '../../components/GetOffersDeals/GetOffersDeals';
import LoginRegisterCheckoutForm from '../../components/ LoginRegisterCheckoutForm/ LoginRegisterCheckoutForm';
import BookingSummaryCard from '../../components/BookingSummaryCard/BookingSummaryCard';


const PayNowOrLater = () => {
    return (
    <>
        <div className='PayNowOrLaterWrapper'>
            <Header />
            
            <Container>
                <Row>
                    <Col md="6">
                        <PayNowOrLaterCompo />
                        <LoginRegisterCheckoutForm className='mt-5' />
                    </Col>
                    <Col md="6">
                       <BookingSummaryCard />
                    </Col>
                </Row>
               
            </Container>
            <GetOffersDeals />
            <Footer />
        </div>
    </>
    );
};

export default PayNowOrLater;